/*
Package pagination contains utilities and convenience structs that implement common pagination idioms within OpenStack APIs.
*/
package pagination
